#!/bin/bash
scala TP7_Samuel_LEBERRE.jar