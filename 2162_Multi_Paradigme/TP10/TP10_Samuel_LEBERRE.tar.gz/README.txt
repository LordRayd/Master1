OS Utilisé:
    Ubuntu 18.04 LTS

Environnement Scala:
    Scala compiler version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.
    Scala code runner version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.

Environnement Java:
    java version "11.0.3" 2019-04-16 LTS
    Java(TM) SE Runtime Environment 18.9 (build 11.0.3+12-LTS)
    Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.3+12-LTS, mixed mode)
    javac 11.0.3

Le fonctionnement du programme n'est pas garanti sous un autre OS que Ubuntu

Pour lancer le programme java il faut lancer le script:
    ./Launch.sh

La réussite du TP10 à été un echec pour moi je pensais y arriver jusqu'a la fin mais je n'ai pas réussit
Je n'ai pas réussit à faire la réétropopagation j'y ai pourtant passé plusieurs heures mais je n'y arrive pas
Je comprend la theorie mais n'arrive pas à la mettre en pratique