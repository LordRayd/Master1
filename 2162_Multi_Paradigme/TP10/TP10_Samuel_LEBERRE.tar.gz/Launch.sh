#!/bin/bash
scala TP10_Samuel_LEBERRE.jar