OS Utilisé:
    Ubuntu 18.04 LTS

Environnement Scala:
    Scala compiler version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.
    Scala code runner version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.

Environnement Java:
    java version "11.0.3" 2019-04-16 LTS
    Java(TM) SE Runtime Environment 18.9 (build 11.0.3+12-LTS)
    Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.3+12-LTS, mixed mode)
    javac 11.0.3

Le fonctionnement du programme n'est pas garanti sous un autre OS que Ubuntu

Vous pouvez lancer le programme avec la commande :
    scala TP6_Samuel_LEBERRE.jar
ou en lançant le script :
    ./Launch.sh


Question 8

    5x5 : 37 ms
    6x6 : 109 ms
    7x7 : environ 300 ms machine pas assez puissante calcul trop couteux
    8x8 : environ 600 ms
    9x9 : environ 1200 ms
    10x10 : environ 1800 ms
    11x11 : environ 2600 ms

Question 9

    5x5 : 40 ms
    6x6 : 47 ms
    7x7 : 60 ms 
    8x8 : 69 ms
    9x9 : 83 ms
    10x10 : 98 ms
    11x11 : 122 ms
    12x12 : 203 ms
    13x13 : 180 ms
    14x14 : 223 ms