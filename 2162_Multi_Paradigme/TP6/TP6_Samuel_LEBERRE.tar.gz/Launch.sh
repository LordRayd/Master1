#!/bin/bash
scala TP6_Samuel_LEBERRE.jar