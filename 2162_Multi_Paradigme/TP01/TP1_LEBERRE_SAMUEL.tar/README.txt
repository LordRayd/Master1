Environnement Java:
    java version "11.0.3" 2019-04-16 LTS
    Java(TM) SE Runtime Environment 18.9 (build 11.0.3+12-LTS)
    Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.3+12-LTS, mixed mode)
    javac 11.0.3

Pour lancer le programme, ouvrez un terminal et placez vous là où se trouve le fichier TP1_LEBERRE_SAMUEL.jar et tapez la commande suivante :
    java -jar TP1_LEBERRE_SAMUEL.jar

Si l'execution se déroule sans problème alors vous aurez le résultat suivant:
    Somme : 1000

    Trouve 76 dans data : true
    Trouve 2 dans data : false

    Nombre de valeur inferieure a 40 : 5
    Nombre de valeur inferieure a 90 : 14

    Tableau Pair
    Indice 0 valeur : 90
    Indice 1 valeur : 32
    Indice 2 valeur : 76
    Indice 3 valeur : 22
    Indice 4 valeur : 80
    Indice 5 valeur : 20
    Indice 6 valeur : 36
    Indice 7 valeur : 42
    Indice 8 valeur : 50
    Indice 9 valeur : 62
    Indice 10 valeur : 72
    Indice 11 valeur : 80
    Indice 12 valeur : 46
    Tableau Impair
    Indice 0 valeur : 17
    Indice 1 valeur : 85
    Indice 2 valeur : 99
    Indice 3 valeur : 91

    Inversion
    Indice 0 valeur : 46
    Indice 1 valeur : 91
    Indice 2 valeur : 99
    Indice 3 valeur : 80
    Indice 4 valeur : 72
    Indice 5 valeur : 62
    Indice 6 valeur : 50
    Indice 7 valeur : 42
    Indice 8 valeur : 36
    Indice 9 valeur : 20
    Indice 10 valeur : 80
    Indice 11 valeur : 22
    Indice 12 valeur : 76
    Indice 13 valeur : 85
    Indice 14 valeur : 32
    Indice 15 valeur : 90
    Indice 16 valeur : 17