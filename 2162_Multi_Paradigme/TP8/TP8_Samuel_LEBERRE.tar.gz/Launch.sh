#!/bin/bash
scala TP8_Samuel_LEBERRE.jar