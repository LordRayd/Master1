OS Utilisé:
    Ubuntu 18.04 LTS

Environnement Scala:
    Scala compiler version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.
    Scala code runner version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.

Environnement Java:
    java version "11.0.3" 2019-04-16 LTS
    Java(TM) SE Runtime Environment 18.9 (build 11.0.3+12-LTS)
    Java HotSpot(TM) 64-Bit Server VM 18.9 (build 11.0.3+12-LTS, mixed mode)
    javac 11.0.3

Le fonctionnement du programme n'est pas garanti sous un autre OS que Ubuntu

Vous pouvez lancer le programme avec la commande :
    scala Anagramme.jar
ou de lancer le fichier Launch.sh