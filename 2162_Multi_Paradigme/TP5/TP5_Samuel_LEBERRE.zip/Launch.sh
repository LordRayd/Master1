#!/bin/bash
scala TP5_Samuel_LEBERRE.jar