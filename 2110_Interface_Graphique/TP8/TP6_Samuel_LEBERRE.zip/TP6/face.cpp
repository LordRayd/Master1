#include "face.h"

Face::Face(Vertex *p1, Vertex *p2, Vertex *p3)
{
    this->p1 = p1;
    this->p2 = p2;
    this->p3 = p3;

}
