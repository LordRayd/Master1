La partie du Tp concernant la réalisation des premières intéractions graphique se trouvent dans le dossier Chat
Pour les lancerr ouvrir le fichier "TP2.html" dans un navigateur web (pas internet explorer execution non garantie)

La partie de conception du candy crush est contenu dans l'image "Candy Crush.png"
Cette image est un diagramme d'exécution du candy crush tels quue je l'ai conçut
Au deuxième click d'un utilisateur on vérifie si les bonbons peuvent être échangé
On bloque les clicks de  l'utilisateur
Si oui, 
    on les échange de position et on réalise la/les combianaisons rendus possible en faisant
    disparaitre les bonbons concerné et on fait desscendre les bonbons au dessus, on augmente également le score.
    On vérifie ensuite si une nouvelle combinaison est possible en comparant chacun des bonbons 
    avec ses voisins Horizontaux et verticaux 
On réautorise l'utilisateur à clicker 