Pour pouvoir avoir accès à la page web double cliquer sur TP1.html

On doit ensuite choisir pour la graphique à traits:
    - la valeur du début soit 157 pour l'exemple.
    - le nombre d'itération soit 200 pour voir les 200 premières valeurs.

Pour le graphique à bar on choisit :
    - le nombre de valeurs que l'on souhaite affiché