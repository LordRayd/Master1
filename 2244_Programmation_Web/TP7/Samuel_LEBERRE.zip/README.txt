Samuel LE BERRE

L'application lance une première fois le traitement et l'affiche dans la div pyplot-chart
Toutes les 10 secondes la dernières infos importantes est actualisés
Toutes les 4 secondes les données du graphe sont mise à jour.