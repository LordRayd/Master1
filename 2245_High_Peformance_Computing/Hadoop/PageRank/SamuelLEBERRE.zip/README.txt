Extraction résulats trouvé
Je ne recupere que la moitié des liens semble t il
100 : 
    LINK_CNT=11291
    PAGE_CNT=100
1000:
    LINK_CNT=111787
    PAGE_CNT=1000
10000:
    LINK_CNT=991136
    PAGE_CNT=10000
100000:
    LINK_CNT=4312371
    PAGE_CNT=100000
all :
    LINK_CNT=53952264
    PAGE_CNT=3744189
PageRank trouvé
100: error lors de l'execution
    PAGE_RANK counter= 3
    PAGE_CNT counter= 100
    loop 1 : pagerank average= 3.0E-5
    PAGE_RANK counter= 0
    PAGE_CNT counter= 10867
    loop 2 : pagerank average= 0.0
1000 :

10000:

100000:

all: