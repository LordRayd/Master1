OS Utilisé:
    Windows 10

Environnement Scala:
    Scala compiler version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.
    Scala code runner version 2.13.1 -- Copyright 2002-2019, LAMP/EPFL and Lightbend, Inc.

Pour lancer le programme, il vous faudra d'abord le compiler avec la commande:
    scalac ./Anagramme.scala
Puis vous pourrez le lancer avec la commande
    scala Anagramme

Déroulement de l'exécution:
Le programme vous demandera de rentrer un mot (ou une phrase) de votre choix.
Il vous affichera ensuite le nombre d'anagramme réalisable à l'aide des lettres de ce mot.
Pour tous les voir s'afficher vous devrez entrer le caractère 'y', tout autre caractère mettra fin au programme.
